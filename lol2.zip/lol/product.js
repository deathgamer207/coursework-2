products = [
    {
        id: 1001,
        title: "football",
        location: "DPS Dubai",
        subject:"sports",
        price: 1000,
        image: "footballl.jpg",
        availablespace: 18,
        rating: 4
    },
    {
        id: 1002,
        title: "basketball",
        location: "Lotus Valley Dubai",
        subject:"sports",
        price: 2000,
        image: "basketballl.jpg",
        availablespace: 25,
        rating: 5
    },
    {
        id: 1003,
        title: "hockey",
        location: "Middlesex Dubai",
        subject:"sports",
        price: 1500,
        image: "hockeyy.jpg",
        availablespace: 10,
        rating: 3
    },
    {
        id: 1004,
        title: "art",
        location: "Exelsior Dubai",
        subject:"Art",
        price: 1400,
        image: "artt.jpg",
        availablespace: 15,
        rating: 5
    },
    {
        id: 1005,
        title: "readingg",
        location: "Gems Dubai",
        subject:"researcher",
        price: 1300,
        image: "readingg.jpg",
        availablespace: 20,
        rating: 2
    },
    {
        id: 1006,
        title: "roboticss",
        location: "Middlesex Dubai",
        subject:"Technical",
        price: 1800,
        image: "roboticss.jpg",
        availablespace: 12,
        rating: 1
    },
    {
        id: 1007,
        title: "horse riding",
        location: "sports Dubai",
        subject:"sports",
        price: 500,
        image: "horse.jpg",
        availablespace: 10,
        rating: 1
    },
    {
        id: 1008,
        title: "badminton",
        location: "Exelsior Dubai",
        subject:"sports",
        price: 800,
        image: "badminton.jpg",
        availablespace: 15,
        rating: 2
    },
    {
        id: 1009,
        title: "dance",
        location: "Heritage Dubai",
        subject:"Dance",
        price: 1100,
        image: "dance.jpg",
        availablespace: 20,
        rating: 4
    },
    {
        id: 1010,
        title: "music",
        location: "Middlesex Dubai",
        subject:"melody",
        price: 1800,
        image: "music.jpg",
        availablespace: 12,
        rating: 5
    },
    {
        id: 1011,
        title: "yoga",
        location: "Shrajah Dubai ",
        subject:"human anatomy",
        price: 15,
        image: "yoga.jpg",
        availablespace: 20,
        rating: 3
    },
    {
        id: 1012,
        title: "chess",
        location: "Lester Dubai",
        subject:"sports",
        price: 1900,
        image: "chess.jpg",
        availablespace: 12,
        rating: 4
    },


]







