# after-school
after-school activities website
Initial Project Setup:

Set up the basic project structure, including HTML, CSS, and initial JavaScript files.
Initialize a Git repository and make the initial commit.
# Link for my website
link for website: https://deathgamer207.github.io/after-school/
# Link for my Repository
link for repistory:https://github.com/deathgamer207/after-school